import { useState } from "react";
import { TicTacToeGame } from "./components/TicTacToe";
import { Toaster } from "sonner";
import "@fontsource/inter";
import "./index.css";

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-primary/10 to-primary/5 flex flex-col items-center justify-center p-4">
      <header className="mb-8 text-center">
        <h1 className="text-4xl font-bold text-primary">Tic Tac Toe</h1>
        <p className="text-muted-foreground mt-2">Play the classic game of X's and O's</p>
      </header>
      
      <main className="w-full max-w-3xl mx-auto flex-1 flex flex-col items-center justify-center">
        <TicTacToeGame />
      </main>
      
      <footer className="mt-8 w-full max-w-3xl mx-auto flex justify-center items-center">
        <p className="text-sm text-muted-foreground">
          Made with ❤️ for your entertainment
        </p>
      </footer>
      
      <Toaster position="top-center" />
    </div>
  );
}

export default App;
