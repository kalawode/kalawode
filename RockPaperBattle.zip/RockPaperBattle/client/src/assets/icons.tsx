import React from "react";

// Rock icon
export const RockIcon = ({ className = "" }: { className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
  >
    <path d="M6.5 14.5s0 2 1 3c1.5 1.5 4 1.5 4 1.5" />
    <path d="M12.5 19c1.5 0 3.5-1 4-2" />
    <path d="M3 14c0-4 1-8 3-8 3 0 3 1 3 1" />
    <path d="M9 6.5c1-.5 2.5-.5 3 0 .5.5 1 1.5 1 2.5 0 .5 0 3 2 3 2 0 3 1 3 3 0 0 .5 1 2 1" />
    <path d="M18 10c1 0 2 1 2 2" />
    <path d="M5 4a1 1 0 0 0-1 1" />
  </svg>
);

// Paper icon
export const PaperIcon = ({ className = "" }: { className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
  >
    <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
    <line x1="7" y1="7" x2="15" y2="7" />
    <line x1="7" y1="11" x2="17" y2="11" />
    <line x1="7" y1="15" x2="13" y2="15" />
  </svg>
);

// Scissors icon
export const ScissorsIcon = ({ className = "" }: { className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
  >
    <circle cx="6" cy="6" r="3" />
    <circle cx="6" cy="18" r="3" />
    <line x1="20" y1="4" x2="8.12" y2="15.88" />
    <line x1="14.47" y1="14.48" x2="20" y2="20" />
    <line x1="8.12" y1="8.12" x2="12" y2="12" />
  </svg>
);
