import { useState, useEffect } from "react";
import GameChoice from "./GameChoice";
import GameResult from "./GameResult";
import GameScoreboard from "./GameScoreboard";
import GameControls from "./GameControls";
import { determineWinner, type Choice, type GameOutcome } from "../lib/gameLogic";
import { useAudio } from "../lib/stores/useAudio";
import { toast } from "sonner";

interface GameBoardProps {
  isMobile: boolean;
}

const GameBoard = ({ isMobile }: GameBoardProps) => {
  const [playerChoice, setPlayerChoice] = useState<Choice | null>(null);
  const [computerChoice, setComputerChoice] = useState<Choice | null>(null);
  const [result, setResult] = useState<GameOutcome | null>(null);
  const [playerScore, setPlayerScore] = useState(0);
  const [computerScore, setComputerScore] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [gameHistory, setGameHistory] = useState<{ round: number; result: GameOutcome }[]>([]);
  const [round, setRound] = useState(1);

  const { setHitSound, setSuccessSound, playHit, playSuccess } = useAudio();

  // Load audio assets
  useEffect(() => {
    // Set up sounds
    const hitAudio = new Audio("/sounds/hit.mp3");
    const successAudio = new Audio("/sounds/success.mp3");

    setHitSound(hitAudio);
    setSuccessSound(successAudio);

    return () => {
      hitAudio.pause();
      successAudio.pause();
    };
  }, [setHitSound, setSuccessSound]);

  const handleChoice = (choice: Choice) => {
    if (isPlaying) return;
    
    setIsPlaying(true);
    setPlayerChoice(choice);
    
    // Simulate computer thinking
    setTimeout(() => {
      const computerSelection = ["rock", "paper", "scissors"][Math.floor(Math.random() * 3)] as Choice;
      setComputerChoice(computerSelection);
      
      const outcome = determineWinner(choice, computerSelection);
      setResult(outcome);
      
      // Update scores
      if (outcome === "win") {
        setPlayerScore(prev => prev + 1);
        playSuccess();
        toast.success("You won this round!");
      } else if (outcome === "lose") {
        setComputerScore(prev => prev + 1);
        playHit();
        toast.error("Computer won this round!");
      } else {
        playHit();
        toast.info("It's a draw!");
      }
      
      // Update game history
      setGameHistory(prev => [...prev, { round, result: outcome }]);
      setRound(prev => prev + 1);
      
      setIsPlaying(false);
    }, 1000);
  };

  const resetGame = () => {
    setPlayerChoice(null);
    setComputerChoice(null);
    setResult(null);
    setPlayerScore(0);
    setComputerScore(0);
    setGameHistory([]);
    setRound(1);
    toast.info("Game reset! Choose your weapon.");
  };

  const playAgain = () => {
    setPlayerChoice(null);
    setComputerChoice(null);
    setResult(null);
    toast.info("Next round! Choose your weapon.");
  };

  return (
    <div className="w-full bg-card rounded-lg shadow-lg p-6 md:p-8">
      <GameScoreboard playerScore={playerScore} computerScore={computerScore} round={round} />
      
      <div className={`mt-8 md:mt-12 flex ${isMobile ? 'flex-col' : 'flex-row'} items-center justify-center gap-8`}>
        <div className={`${isMobile ? 'order-2' : 'order-1'} flex-1 flex flex-col items-center`}>
          <h2 className="text-xl font-semibold mb-4">Your Choice</h2>
          {playerChoice ? (
            <GameChoice choice={playerChoice} size="large" animate />
          ) : (
            <div className="flex flex-wrap justify-center gap-4">
              <GameChoice choice="rock" onClick={() => handleChoice("rock")} disabled={isPlaying} />
              <GameChoice choice="paper" onClick={() => handleChoice("paper")} disabled={isPlaying} />
              <GameChoice choice="scissors" onClick={() => handleChoice("scissors")} disabled={isPlaying} />
            </div>
          )}
        </div>
        
        {(playerChoice && computerChoice) && (
          <div className={`${isMobile ? 'order-1 my-4' : 'order-2'}`}>
            <GameResult outcome={result} />
          </div>
        )}
        
        <div className={`${isMobile ? 'order-3' : 'order-3'} flex-1 flex flex-col items-center`}>
          <h2 className="text-xl font-semibold mb-4">Computer's Choice</h2>
          {computerChoice ? (
            <GameChoice choice={computerChoice} size="large" animate isComputer />
          ) : (
            <div className="w-24 h-24 rounded-full bg-muted/50 flex items-center justify-center">
              {playerChoice ? (
                <div className="animate-pulse">Thinking...</div>
              ) : (
                <div>Waiting...</div>
              )}
            </div>
          )}
        </div>
      </div>
      
      <GameControls 
        onPlayAgain={playAgain} 
        onReset={resetGame} 
        showPlayAgain={!!playerChoice && !!computerChoice}
      />
    </div>
  );
};

export default GameBoard;
