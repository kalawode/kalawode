import { cn } from "../lib/utils";
import { RockIcon, PaperIcon, ScissorsIcon } from "../assets/icons";

interface GameChoiceProps {
  choice: "rock" | "paper" | "scissors";
  onClick?: () => void;
  size?: "normal" | "large";
  disabled?: boolean;
  animate?: boolean;
  isComputer?: boolean;
}

const GameChoice = ({ 
  choice, 
  onClick, 
  size = "normal", 
  disabled = false,
  animate = false,
  isComputer = false
}: GameChoiceProps) => {
  // Size classes based on prop
  const sizeClasses = size === "large" 
    ? "w-32 h-32 text-4xl"
    : "w-20 h-20 text-2xl";
  
  // Animation classes
  const animationClasses = animate
    ? "animate-bounce"
    : "";
  
  // Computer specific classes
  const computerClasses = isComputer && size === "large"
    ? "bg-secondary/10 border-secondary" 
    : "";

  return (
    <button
      onClick={onClick}
      disabled={disabled || !onClick}
      className={cn(
        "rounded-full flex items-center justify-center border-4 transition-all",
        sizeClasses,
        animationClasses,
        computerClasses,
        choice === "rock" && "bg-red-100 border-red-500 hover:bg-red-200",
        choice === "paper" && "bg-blue-100 border-blue-500 hover:bg-blue-200",
        choice === "scissors" && "bg-yellow-100 border-yellow-500 hover:bg-yellow-200",
        (disabled || !onClick) ? "opacity-80 cursor-default" : "cursor-pointer hover:shadow-lg",
      )}
      aria-label={`Choose ${choice}`}
    >
      {choice === "rock" && <RockIcon className={size === "large" ? "w-16 h-16" : "w-10 h-10"} />}
      {choice === "paper" && <PaperIcon className={size === "large" ? "w-16 h-16" : "w-10 h-10"} />}
      {choice === "scissors" && <ScissorsIcon className={size === "large" ? "w-16 h-16" : "w-10 h-10"} />}
    </button>
  );
};

export default GameChoice;
