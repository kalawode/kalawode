import { useEffect } from "react";
import { motion } from "framer-motion";
import { Trophy, Frown, ScanSearch } from "lucide-react";
import { type GameOutcome } from "../lib/gameLogic";

interface GameResultProps {
  outcome: GameOutcome | null;
}

const GameResult = ({ outcome }: GameResultProps) => {
  let Icon = ScanSearch;
  let text = "Calculating...";
  let color = "text-muted-foreground";
  let bgColor = "bg-muted/20";
  
  if (outcome === "win") {
    Icon = Trophy;
    text = "You Win!";
    color = "text-green-600";
    bgColor = "bg-green-100";
  } else if (outcome === "lose") {
    Icon = Frown;
    text = "You Lose!";
    color = "text-red-600";
    bgColor = "bg-red-100";
  } else if (outcome === "draw") {
    Icon = ScanSearch;
    text = "It's a Draw!";
    color = "text-blue-600";
    bgColor = "bg-blue-100";
  }

  return (
    <motion.div
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 0.3 }}
      className={`${bgColor} ${color} px-6 py-3 rounded-full font-bold flex items-center`}
    >
      <Icon className="mr-2 h-5 w-5" />
      <span>{text}</span>
    </motion.div>
  );
};

export default GameResult;
