import { Card, CardContent } from "./ui/card";
import { User, Monitor } from "lucide-react";

interface GameScoreboardProps {
  playerScore: number;
  computerScore: number;
  round: number;
}

const GameScoreboard = ({ playerScore, computerScore, round }: GameScoreboardProps) => {
  return (
    <div className="w-full">
      <div className="flex justify-center mb-2">
        <div className="px-4 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium">
          Round {round}
        </div>
      </div>
      
      <div className="flex justify-between gap-4">
        <Card className="flex-1">
          <CardContent className="p-4 flex items-center justify-between">
            <div className="flex items-center">
              <div className="mr-3 p-2 rounded-full bg-primary/10">
                <User className="h-5 w-5 text-primary" />
              </div>
              <span className="font-medium">You</span>
            </div>
            <span className="text-2xl font-bold">{playerScore}</span>
          </CardContent>
        </Card>
        
        <Card className="flex-1">
          <CardContent className="p-4 flex items-center justify-between">
            <div className="flex items-center">
              <div className="mr-3 p-2 rounded-full bg-secondary/10">
                <Monitor className="h-5 w-5 text-secondary" />
              </div>
              <span className="font-medium">Computer</span>
            </div>
            <span className="text-2xl font-bold">{computerScore}</span>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default GameScoreboard;
