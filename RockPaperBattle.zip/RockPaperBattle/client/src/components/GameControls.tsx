import { Button } from "./ui/button";
import { RefreshCw, Play } from "lucide-react";

interface GameControlsProps {
  onPlayAgain: () => void;
  onReset: () => void;
  showPlayAgain: boolean;
}

const GameControls = ({ onPlayAgain, onReset, showPlayAgain }: GameControlsProps) => {
  return (
    <div className="mt-8 flex flex-col md:flex-row items-center justify-center gap-4">
      {showPlayAgain && (
        <Button 
          onClick={onPlayAgain} 
          className="min-w-[150px]"
          variant="default"
        >
          <Play className="mr-2 h-4 w-4" />
          Play Again
        </Button>
      )}
      
      <Button 
        onClick={onReset} 
        variant="outline"
        className="min-w-[150px]"
      >
        <RefreshCw className="mr-2 h-4 w-4" />
        Reset Game
      </Button>
    </div>
  );
};

export default GameControls;
