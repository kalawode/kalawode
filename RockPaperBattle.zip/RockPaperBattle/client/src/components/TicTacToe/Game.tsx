import React, { useState, useEffect } from "react";
import Board from "./Board";
import { Button } from "../ui/button";
import { toast } from "sonner";
import { useAudio } from "../../lib/stores/useAudio";
import { RefreshCw, Info, User, Monitor } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";

// Game modes
type GameMode = "manual" | "computer";

const Game: React.FC = () => {
  const [history, setHistory] = useState([{ squares: Array(9).fill(null) }]);
  const [stepNumber, setStepNumber] = useState(0);
  const [xIsNext, setXIsNext] = useState(true);
  const [winningLine, setWinningLine] = useState<number[] | null>(null);
  const [showRules, setShowRules] = useState(false);
  const [gameMode, setGameMode] = useState<GameMode>("manual");
  const [computerThinking, setComputerThinking] = useState(false);
  
  const { playHit, playSuccess } = useAudio();

  const current = history[stepNumber];
  const winner = calculateWinner(current.squares);
  const isGameOver = winner || current.squares.every(square => square !== null);

  // Check for winner or draw
  useEffect(() => {
    if (winner) {
      setWinningLine(calculateWinningLine(current.squares));
      playSuccess();
      
      if (gameMode === "computer") {
        const winnerText = winner === "X" ? "You win!" : "Computer wins!";
        toast.success(winnerText);
      } else {
        toast.success(`Player ${winner} wins!`);
      }
    } else if (current.squares.every(square => square !== null)) {
      playHit();
      toast.info("Game ended in a draw!");
    }
  }, [current.squares, winner, playSuccess, playHit, gameMode]);

  // Computer's move
  useEffect(() => {
    if (gameMode === "computer" && !xIsNext && !winner && !current.squares.every(square => square !== null)) {
      // Add a small delay to simulate computer "thinking"
      setComputerThinking(true);
      const timeoutId = setTimeout(() => {
        makeComputerMove();
        setComputerThinking(false);
      }, 750);
      
      return () => clearTimeout(timeoutId);
    }
  }, [gameMode, xIsNext, current.squares, winner]);

  // Make a move on the board
  const handleClick = (i: number) => {
    // If it's computer's turn or the game is over or the square is filled, or computer is "thinking", return
    if ((gameMode === "computer" && !xIsNext) || winner || current.squares[i] || computerThinking) {
      return;
    }
    
    makeMove(i);
  };

  // Handle making a move
  const makeMove = (i: number) => {
    const currentHistory = history.slice(0, stepNumber + 1);
    const currentSquares = [...current.squares];
    
    // Mark the square with X or O
    currentSquares[i] = xIsNext ? "X" : "O";
    
    // Play sound effect
    playHit();
    
    // Update the state
    setHistory([...currentHistory, { squares: currentSquares }]);
    setStepNumber(currentHistory.length);
    setXIsNext(!xIsNext);
  };

  // Computer's move logic
  const makeComputerMove = () => {
    const currentSquares = [...current.squares];
    
    // Get the best move for the computer (O)
    const bestMove = findBestMove(currentSquares);
    
    if (bestMove !== -1) {
      makeMove(bestMove);
    }
  };

  // Find the best move for the computer
  const findBestMove = (squares: Array<string | null>): number => {
    // First, check if computer can win in the next move
    const winningMove = findWinningMove(squares, "O");
    if (winningMove !== -1) return winningMove;
    
    // Second, check if player can win in the next move and block it
    const blockingMove = findWinningMove(squares, "X");
    if (blockingMove !== -1) return blockingMove;
    
    // Take center if it's free
    if (squares[4] === null) return 4;
    
    // Take a corner if available
    const corners = [0, 2, 6, 8];
    const availableCorners = corners.filter(corner => squares[corner] === null);
    if (availableCorners.length > 0) {
      return availableCorners[Math.floor(Math.random() * availableCorners.length)];
    }
    
    // Take any available side
    const sides = [1, 3, 5, 7];
    const availableSides = sides.filter(side => squares[side] === null);
    if (availableSides.length > 0) {
      return availableSides[Math.floor(Math.random() * availableSides.length)];
    }
    
    // If no moves are found (shouldn't happen in a normal game)
    return -1;
  };

  // Find a winning move for the given player
  const findWinningMove = (squares: Array<string | null>, player: string): number => {
    const lines = [
      [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
      [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
      [0, 4, 8], [2, 4, 6]             // Diagonals
    ];
    
    for (const line of lines) {
      const [a, b, c] = line;
      // Check if two positions have the player's symbol and the third is empty
      if (squares[a] === player && squares[b] === player && squares[c] === null) return c;
      if (squares[a] === player && squares[c] === player && squares[b] === null) return b;
      if (squares[b] === player && squares[c] === player && squares[a] === null) return a;
    }
    
    return -1;  // No winning move found
  };
  
  // Jump to a previous move
  const jumpTo = (step: number) => {
    setStepNumber(step);
    setXIsNext(step % 2 === 0);
    setWinningLine(null);
  };

  // Reset the game
  const resetGame = () => {
    setHistory([{ squares: Array(9).fill(null) }]);
    setStepNumber(0);
    setXIsNext(true);
    setWinningLine(null);
    toast.info(`Game reset! ${gameMode === "manual" ? "Player X" : "You"} start${gameMode === "manual" ? "s" : ""}.`);
  };

  // Change game mode
  const handleModeChange = (mode: GameMode) => {
    setGameMode(mode);
    resetGame();
  };

  // Determine game status text
  let status;
  if (winner) {
    if (gameMode === "computer") {
      status = winner === "X" ? "You win!" : "Computer wins!";
    } else {
      status = `Winner: ${winner}`;
    }
  } else if (current.squares.every(square => square !== null)) {
    status = "Game ended in a draw!";
  } else {
    if (gameMode === "computer") {
      status = xIsNext ? "Your turn (X)" : "Computer's turn (O)";
    } else {
      status = `Next player: ${xIsNext ? "X" : "O"}`;
    }
  }

  return (
    <div className="w-full bg-card rounded-lg shadow-lg p-6 md:p-8">
      <div className="mb-6 flex items-center justify-between">
        <div className="px-4 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium">
          Game #{Math.ceil(stepNumber / 2) + 1}
        </div>
        <Button 
          variant="outline" 
          size="sm" 
          onClick={() => setShowRules(!showRules)}
          className="flex items-center gap-1"
        >
          <Info className="h-4 w-4" />
          Rules
        </Button>
      </div>
      
      {showRules && (
        <div className="mb-6 p-4 border border-slate-200 rounded-md bg-slate-50">
          <h3 className="font-bold mb-2">How to Play Tic Tac Toe</h3>
          <ul className="list-disc pl-5 space-y-1 text-sm">
            <li>Players take turns placing X or O on the board</li>
            <li>X goes first, followed by O</li>
            <li>The first player to get 3 marks in a row (horizontally, vertically, or diagonally) wins</li>
            <li>If all squares are filled and no one has 3 in a row, the game is a draw</li>
          </ul>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => setShowRules(false)} 
            className="mt-2"
          >
            Close
          </Button>
        </div>
      )}

      <Tabs 
        defaultValue="manual" 
        value={gameMode}
        onValueChange={(v) => handleModeChange(v as GameMode)}
        className="mb-6"
      >
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="manual" className="flex items-center gap-2">
            <User className="h-4 w-4" />
            Two Players
          </TabsTrigger>
          <TabsTrigger value="computer" className="flex items-center gap-2">
            <Monitor className="h-4 w-4" />
            Vs Computer
          </TabsTrigger>
        </TabsList>
      </Tabs>
      
      <div className="text-xl font-bold mb-4 text-center text-primary">
        {status}
        {gameMode === "computer" && computerThinking && !isGameOver && (
          <div className="text-sm font-normal text-muted-foreground mt-1 animate-pulse">
            Computer is thinking...
          </div>
        )}
      </div>
      
      <div className="flex flex-col items-center">
        <Board 
          squares={current.squares} 
          onClick={handleClick} 
          winningLine={winningLine}
        />
        
        <Button 
          onClick={resetGame} 
          className="mt-4 min-w-[150px]"
        >
          <RefreshCw className="mr-2 h-4 w-4" />
          New Game
        </Button>
      </div>
      
      <div className="mt-6">
        <h3 className="font-bold mb-2">Game History</h3>
        <div className="max-h-48 overflow-y-auto p-2 border border-slate-200 rounded">
          <ol className="space-y-1">
            {history.map((_, move) => (
              <li key={move}>
                <Button 
                  variant={move === stepNumber ? "default" : "ghost"}
                  size="sm"
                  onClick={() => jumpTo(move)}
                  className="w-full text-left justify-start"
                >
                  {move ? `Go to move #${move}` : 'Go to game start'}
                </Button>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </div>
  );
};

// Helper function to calculate the winner
function calculateWinner(squares: Array<string | null>): string | null {
  const lines = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6],
  ];
  
  for (let i = 0; i < lines.length; i++) {
    const [a, b, c] = lines[i];
    if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
      return squares[a];
    }
  }
  
  return null;
}

// Helper function to determine which line won
function calculateWinningLine(squares: Array<string | null>): number[] | null {
  const lines = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6],
  ];
  
  for (let i = 0; i < lines.length; i++) {
    const [a, b, c] = lines[i];
    if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
      return lines[i];
    }
  }
  
  return null;
}

export default Game;