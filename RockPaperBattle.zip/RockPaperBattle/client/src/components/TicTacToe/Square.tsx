import React from "react";
import { cn } from "../../lib/utils";

interface SquareProps {
  value: string | null;
  onClick: () => void;
  isWinning: boolean;
}

const Square: React.FC<SquareProps> = ({ value, onClick, isWinning }) => {
  return (
    <button
      className={cn(
        "w-20 h-20 md:w-24 md:h-24 border border-slate-400 bg-white flex items-center justify-center text-3xl md:text-4xl font-bold transition-colors",
        value === "X" && "text-blue-600",
        value === "O" && "text-red-600",
        isWinning && "bg-green-200 border-green-500",
        !value && "hover:bg-slate-100"
      )}
      onClick={onClick}
      disabled={!!value}
      aria-label={value ? `Square with ${value}` : "Empty square"}
    >
      {value}
    </button>
  );
};

export default Square;