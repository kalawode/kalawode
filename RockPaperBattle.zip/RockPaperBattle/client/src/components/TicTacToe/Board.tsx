import React from "react";
import Square from "./Square";
import { cn } from "../../lib/utils";

interface BoardProps {
  squares: Array<string | null>;
  onClick: (i: number) => void;
  winningLine: number[] | null;
}

const Board: React.FC<BoardProps> = ({ squares, onClick, winningLine }) => {
  const renderSquare = (i: number) => {
    const isWinningSquare = winningLine?.includes(i) || false;
    
    return (
      <Square
        value={squares[i]}
        onClick={() => onClick(i)}
        isWinning={isWinningSquare}
        key={i}
      />
    );
  };

  // Create a 3x3 grid of squares
  const renderRow = (startIndex: number) => {
    return (
      <div className="flex">
        {renderSquare(startIndex)}
        {renderSquare(startIndex + 1)}
        {renderSquare(startIndex + 2)}
      </div>
    );
  };

  return (
    <div className="mb-4">
      {renderRow(0)}
      {renderRow(3)}
      {renderRow(6)}
    </div>
  );
};

export default Board;