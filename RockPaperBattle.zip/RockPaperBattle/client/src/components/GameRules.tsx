import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "./ui/dialog";
import { Button } from "./ui/button";

interface GameRulesProps {
  onClose: () => void;
}

const GameRules = ({ onClose }: GameRulesProps) => {
  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Game Rules</DialogTitle>
          <DialogDescription>
            How to play Rock Paper Scissors
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 my-4">
          <p>Rock Paper Scissors is a classic hand game usually played between two people. Each player simultaneously forms one of three shapes with their hand:</p>
          
          <ul className="list-disc pl-5 space-y-2">
            <li><strong>Rock:</strong> A closed fist</li>
            <li><strong>Paper:</strong> A flat hand with fingers and thumb extended</li>
            <li><strong>Scissors:</strong> A fist with the index and middle fingers extended, forming a V</li>
          </ul>
          
          <p className="font-medium mt-4">The winner is determined by these rules:</p>
          
          <ul className="list-disc pl-5 space-y-2">
            <li>Rock crushes Scissors (Rock wins)</li>
            <li>Scissors cuts Paper (Scissors wins)</li>
            <li>Paper covers Rock (Paper wins)</li>
            <li>If both players choose the same shape, it's a tie</li>
          </ul>
        </div>
        
        <DialogFooter>
          <Button onClick={onClose}>Got it</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default GameRules;
