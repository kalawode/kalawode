export type Choice = "rock" | "paper" | "scissors";
export type GameOutcome = "win" | "lose" | "draw";

export function determineWinner(playerChoice: Choice, computerChoice: Choice): GameOutcome {
  // Draw condition
  if (playerChoice === computerChoice) {
    return "draw";
  }
  
  // Win conditions for the player
  if (
    (playerChoice === "rock" && computerChoice === "scissors") ||
    (playerChoice === "paper" && computerChoice === "rock") ||
    (playerChoice === "scissors" && computerChoice === "paper")
  ) {
    return "win";
  }
  
  // All other conditions are losses
  return "lose";
}

// Helper function to get a random choice for the computer
export function getRandomChoice(): Choice {
  const choices: Choice[] = ["rock", "paper", "scissors"];
  const randomIndex = Math.floor(Math.random() * choices.length);
  return choices[randomIndex];
}

// Descriptions for each choice
export const choiceDescriptions = {
  rock: "Rock crushes scissors",
  paper: "Paper covers rock",
  scissors: "Scissors cut paper"
};
